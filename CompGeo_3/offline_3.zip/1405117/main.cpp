#include <bits/stdc++.h>
#include <windows.h>
#include <glut.h>

#define pi (2*acos(0.0))
#define inf 1e18
#define epsilon 1e-6

using namespace std;


int calc_approx (double x)
{
    if (fabs(x) < epsilon)
        return 0;
    else return x < 0 ? -1 : 1;
}

double X, Y;
class Point
{
public:
    double x, y;
    Point(){}
    Point(double x, double y)
    {
        this->x = x;
        this->y = y;
    }


    bool operator < (const Point& u) const  {
         return calc_approx(y - u.y) < 0 || (calc_approx(y - u.y) == 0 && calc_approx(x-u.x) > 0);
    }
    bool operator > (const Point& u) const  {
         return u < *this;
    }

    bool operator ==(const Point& u) const {
         return calc_approx(x - u.x) == 0 && calc_approx(y - u.y) == 0;
    }

    bool operator != (const Point& u) const {
         return !(*this == u);
    }




    Point operator - (const Point& u)  {
         return Point(x - u.x, y - u.y);
    }

    Point operator + (const Point& u)  {
         return Point(x+u.x,y+u.y);
    }

    Point operator / (const double u)  {
        return Point(x / u, y / u);
    }
    Point operator * (const double u)  {
         return Point(x * u, y * u);
    }


};

vector <Point> VectorPoint;


double Dot (Point u, Point v)
{
    return u.x * v.x + u.y * v.y;
}

double Cross (Point u, Point v)
{
    return u.x * v.y - u.y * v.x;
}

bool intersectBool(Point u, Point v, Point uu, Point vv) {
    double k,kk,kkk,kkkk;
    k = Cross(v-u, uu-u);
    kk = Cross(v-u, vv-u);
    kkk = Cross(vv-uu, u-uu);
    kkkk = Cross(vv-uu,v-uu);
    return calc_approx(k)*calc_approx(kk)<0 && calc_approx(kkk)*calc_approx(kkkk)<0;
}

bool onSegment (Point pp, Point u, Point v)
{
    return calc_approx(Cross(u-pp, v-pp)) == 0 && calc_approx(Dot(u-pp, v-pp)) < 0;
}

bool getIntersection (Point p, Point v, Point q, Point w, Point& o) {
    if (calc_approx(Cross(v, w)) != 0)
    {
        Point str = p - q;
        double zz = Cross(w, str) / Cross(v, w);
        o = p + v * zz;
        return true;
    }

    return false;
}


class Segment{
public:
    Point first, last;
    int id;
    Segment(){}
    Segment(Point u, Point v) {
        first = u;
        last = v;
        //  cout<<"fsddf"<<endl;
        if(first < last)
        {
            swap(first, last);
        }
    }
    bool operator == (const Segment& point) const
    {
        return first == point.first && last == point.last;
    }

    double check_x(Segment segment) const{
        double topPoint = (segment.first.x - segment.last.x) * Y - (segment.first.x * segment.last.y - segment.last.x * segment.first.y);
        double bottomPoint = segment.first.y - segment.last.y;
        if(calc_approx(bottomPoint) == 0){
            return X + epsilon;
        }
        else return topPoint / bottomPoint;
    }

    bool operator < (const Segment& segment) const{
        return check_x(*this)<check_x(segment);
    }
};

vector <Segment> EventPointVector;
priority_queue<Point> eventQueue;

void newEvent_func(Segment segment1, Segment segment2, Point point1){
        Point point2;
        if(intersectBool(segment1.first, segment1.last, segment2.first, segment2.last)){
            getIntersection(segment1.first, segment1.last-segment1.first, segment2.first, segment2.last-segment2.first, point2);
            if(point2<point1) eventQueue.push(point2);
        }

}

map< Point, vector<Segment> > topSegVector;
set<Segment> statusQueue;
void eventpoint_handle(Point point);

void intersect_point_find(){
    for(Segment segment : EventPointVector){
        eventQueue.push(segment.first);
        eventQueue.push(segment.last);
        topSegVector[segment.first].push_back(segment);
        //cout<<"hi";
    }
    while(!eventQueue.empty()){
        Point point = eventQueue.top();
        while(!eventQueue.empty() && eventQueue.top() == point)
        {
            //cout<<"pop"<<endl;
            eventQueue.pop();
        }
        eventpoint_handle(point);
        //cout<<"break2"<<endl;
    }
    //cout<<"break2"<<endl;
}

void eventpoint_handle(Point point)
{
    //cout<<"hi"<<endl;
    vector<Segment>U,C,L;

    X = point.x;
    Y = point.y;

    if(topSegVector.count(point))
    {
        U = topSegVector[point];
    }

    Segment tempSegment = Segment(point,Point(point.x-1, point.y+1));
    auto var = statusQueue.lower_bound(tempSegment);

    auto former = var;

    while(true)
    {
        //cout<<"break1"<<endl;
        if(former == statusQueue.begin())
        {
            //cout<<"break2"<<endl;
            break;
            former--;

        }
        if(former->last == point)
        {
            L.push_back(*former);
            //cout<<"break3"<<endl;
        }
        else if(onSegment(point, former->first, former->last))
        {
            C.push_back(*former);
            //cout<<"break4"<<endl;
        }
        else
        {
            //cout<<"break5"<<endl;
            break;

        }
    }

    auto next = var;

    while(true)
    {
        if(next == statusQueue.end())
        {
            //cout<<"break"<<endl;
            break;
        }
        if(next->last == point)
        {
            //cout<<"break2"<<endl;
            L.push_back(*next);
        }
        else if(onSegment(point,next->first,next->last))
        {
            //cout<<"break3"<<endl;
            C.push_back(*next);
        }
        else
        {
            //cout<<"break4"<<endl;
            break;
        }
        next++;
    }


    if(L.size() + C.size() + U.size() > 1)
    {
        VectorPoint.push_back(point);
        //intersection points
        cout<<"Point: "<<point.x<<", "<<point.y<<" ";
        cout<<"Lines: ";
        for(Segment segment : L)
        {
            cout<<segment.id<<" ";
        }
        for(Segment segment : C)
        {
            cout<<segment.id<<" ";
        }
        for(Segment segment : U)
        {
            cout<<segment.id<<" ";
        }
        cout<<endl;

    }
    //cout<<"hi"<<endl;

    Y = point.y + epsilon;
    for(Segment segment : L)
    {
        statusQueue.erase(segment);
    }
    //cout<<"break2"<<endl;
    for(Segment segment : C)
    {
        statusQueue.erase(segment);
    }
    //cout<<"break2"<<endl;
    for(Segment segment : U)
    {
        statusQueue.erase(segment);
    }

    Y = point.y - epsilon;

    for(Segment segment : U)
    {
        statusQueue.insert(segment);
    }
    for(Segment segment : C)
    {
        statusQueue.insert(segment);
    }

    //cout<<"break2"<<endl;
    if(U.size() + C.size() == 0)
    {
        Segment Right, Left;
        Y = point.y;
        auto var = statusQueue.lower_bound(tempSegment);
        if(var!=statusQueue.end() && var!=statusQueue.begin())
        {
            Right = *var;
            Left = *--var;
            newEvent_func(Left,Right,point);
        }
    }
    else
    {

        vector<Segment>curVector;
        Segment left, right;
        Y=point.y-epsilon;

        for(Segment segment : U)
        {
            curVector.push_back(segment);
        }
        for(Segment segment : C)
        {
            curVector.push_back(segment);
        }
        sort(curVector.begin(),curVector.end());
        left=curVector[0];
        right=curVector.back();

        assert(statusQueue.find(left) != statusQueue.end());
        assert(statusQueue.find(right) != statusQueue.end());

        auto varp = statusQueue.lower_bound(left);
        auto varq = statusQueue.upper_bound(right);
        if(varp != statusQueue.begin()) {
            varp--;
            newEvent_func(left,*varp,point);
        }
        if(varq != statusQueue.end()) {
            newEvent_func(right, *varq, point);
        }
    }
    //cout<<"break2"<<endl;

}

void display(){
	//clear the display
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClearColor(0,0,0,0);	//color black
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	/********************
	/ set-up camera here
	********************/
	//load the correct matrix -- MODEL-VIEW matrix
	glMatrixMode(GL_MODELVIEW);

	//initialize the matrix
	glLoadIdentity();
	double X = 0;
	double Y = 0;
	double Z = 15;
    double size = 0.01 * Z;
    gluLookAt(X, Y, Z, X, Y, 0, 0, 1, 0);
	//again select MODEL-VIEW
	glMatrixMode(GL_MODELVIEW);

	//glColor3f(0,0,0.5);
    //drawCircle(Point(0,0),size*2);

//
//                        glColor3f(1,1,1);
//                        for(Segment segment : EventPointVector){
//                            glColor3f(1,0,0);
//                            drawSquare(segment.first, size);
//                            drawSquare(segment.last, size);
//                        }

    for(Segment segment: EventPointVector)
    {
        glColor3f(0,0,0.9);
        glBegin(GL_LINES);{
            glVertex3f(segment.first.x, segment.first.y, 0);
            glVertex3f(segment.last.x, segment.last.y,0);
        }
        glEnd();
    }

    glColor3f(1,0,0);
    for (Point point : VectorPoint)
    {
        //drawCircle(a, Size*2);
        glTranslatef(point.x, point.y,0);
        int n = 100;
        double angle =2*pi/n;
        vector<Point> pointVecNew;

        for(int i=0; i<n; i++)
        {
            pointVecNew.push_back( Point(size*2*cos(i*angle), size*2*sin(i*angle)) );
        }

        for(int i=0;i<n;i++){
            glBegin(GL_TRIANGLES);{
                glVertex3f(0,0,0);
                glVertex3f(pointVecNew[i].x, pointVecNew[i].y,0);
                glVertex3f(pointVecNew[(i+1)%n].x, pointVecNew[(i+1)%n].y, 0);
            }
            glEnd();
        }
        glTranslatef(-point.x, -point.y,0);

    }

//

	//ADD this line in the end --- if you use double buffer (i.e. GL_DOUBLE)
	glutSwapBuffers();
}



void init(){
	//codes for initialization

	//clear the screen
	glClearColor(0,0,0,0);

	/************************
	/ set-up projection here
	************************/
	//load the PROJECTION matrix
	glMatrixMode(GL_PROJECTION);

	//initialize the matrix
	glLoadIdentity();

	//give PERSPECTIVE parameters
	gluPerspective(80,	1,	1,	1000.0);
	//field of view in the Y (vertically)
	//aspect ratio that determines the field of view in the X direction (horizontally)
	//near distance
	//far distance

    ifstream file;
    file.open("input.txt");
    if (!file){cout<<"File is not opened"; exit(1);}
    int n;
    int point_x1, point_x2, point_y1, point_y2;


    file>>n;

    int i = 0;
    while(i<n)
    {
        file>>point_x1>>point_y1>>point_x2>>point_y2;
        //cout<<point_x1<<point_y1<<point_x2<<point_y2<<endl;
        Point point_first = Point(point_x1, point_y1);
        Point point_second = Point(point_x2, point_y2);
        EventPointVector.push_back(Segment(point_first, point_second));
        //cout<<point_first.x<<endl;
        //cout<<EventPointVector[i].first.x<<endl;
        EventPointVector[i].id = i+1;
        i++;
    }
    //cout<<"hi5";

    intersect_point_find();

    //for (Point p:intersect) cout<<p.x<<" "<<p.y<<endl;

    //   sort(events,events+e,compare);//on x coordinate
    //   hv_intersection();
}

int main(int argc, char **argv)
{
    glutInit(&argc,argv);
	glutInitWindowSize(500, 500);
	glutInitWindowPosition(0, 0);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGB);	//Depth, Double buffer, RGB color
	glutCreateWindow("Line-Segment Intersection");
	init();
	glEnable(GL_DEPTH_TEST);	//enable Depth Testing
	glutDisplayFunc(display);	//display callback function
	glutMainLoop();		//The main loop of OpenGL
}

